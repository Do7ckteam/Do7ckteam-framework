<img src="https://Arminn17.ir/images/imgf.jpg"></img>
# Do7ckteam-framework
<a href="https://t.me/Do7ck"><button>telegram channel</button></a>
<a href="https://Arminn17.ir"><button>website</button></a>
# Installation


hacking tools
Penetration testing tools

==================================
# prerequisites
$apt install git
   
$apt install python

==================================
# cloneing & install
$git clone https://github.com/Do7ckteam/Do7ckteam-framework
   
$cd Do7ckteam-framework
   
$python install.py
   
$python2 jrf.py

==================================

code by Arminn_17
https://Arminn17.ir
https://t.me/Arminn_17bot
