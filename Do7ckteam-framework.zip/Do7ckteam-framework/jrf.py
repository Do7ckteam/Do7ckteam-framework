#Arminn_17
#Do7ckteam-framework
#https://Arminn17.ir
#v 1.1
import os
import urllib
ip = urllib.urlopen("http://ip.42.pl/raw").read()

os.system("clrar")
os.system("clear")
os.system("clear")

#logo
print'''
\033[1;34m
                       ..:::::::::..
                  ..:::aad8888888baa:::..
              .::::d:?88888888888?::8b::::.
             .:::d8888:?88888888??a888888b:::.
          .:::d8888888a8888888aa8888888888b:::.
         ::::dP::::::::88888888888::::::::Yb::::
        ::::dP:::::::::Y888888888P:::::::::Yb::::
       ::::d8:::::::::::Y8888888P:::::::::::8b::::
      .::::88::::::::::::Y88888P::::::::::::88::::.
      :::::Y8baaaaaaaaaa88P:T:Y88aaaaaaaaaad8P:::::
      :::::::Y88888888888P::|::Y88888888888P:::::::
      ::::::::::::::::888:::|:::888::::::::::::::::
      `:::::::::::::::8888888888888b::::::::::::::'
       :::::::::::::::88888888888888::::::::::::::
        :::::::::::::d88888888888888:::::::::::::
         ::::::::::::88::88::88:::88::::::::::::
          `::::::::::88::88::88:::88::::::::::'
            `::::::::88::88::P::::88::::::::'
              `::::::88::88:::::::88::::::'
                 ``:::::::::::::::::::''
                      ``:::::::::''


\033[1;m
\033[1;32m
      site : https://Arminn17.ir
      channel : https://t.me/Do7ckteam
      github : https://github.com/Do7ckteam
\033[1;34m
your public ip addres
=====================\033[1;34m
'''
print ip


#addres


print'''
\033[1;32m
         {1} nmap-jilrot
         ======================
         {2} payload
         ======================
         {3} ddos attack
         ======================
         {4} web tools
         ======================
         {5} termux os
         ======================
         {6} password tools
         ======================
         {7} cracking
         ======================
         {8} evil codes
         ======================
         {99}exit
\033[1;m
'''

print ("  ")

#input-x

x = input("Do7ckteam=>  ")

if x == 1:
   os.system("python2 modules/nmap/nmap.py")
if x == 2:
   os.system("python2 modules/payload/payload.py")
if x == 3:
   os.system("python2 modules/ddos/ddos.py")
if x == 4:
   os.system("python2 modules/webtools/webtools.py")
if x == 5:
   os.system("python2 modules/os/os.py")
if x == 6:
   os.system("python2 modules/password/password.py")
if x == 7:
   os.system("python2 modules/crack/crack.py")
if x == 8:
   os.system("python2 modules/evilcode/evilcode.py")
