import os


os.system("unzip modules.zip")
os.system("rm -rf modules.zip")
os.system("apt install python")
os.system("apt install python2")
os.system("apt install python3")
os.system("apt install pip")
os.system("apt install pip2")
os.system("pip2 install requests")
os.system("apt install php")
os.system("apt install nmap")
os.system("apt install mlocate")
os.system("apt install wget")
os.system("pip install wordlist")
os.system("python3 -m pip install requests[socks]")
os.system("pip install bs4")
os.system("pip install requests.auth")
