import os
os.system("clear")
os.system("clear")
print'''



$$$        $$$
$$$$$$$$$$$$$$================================\
$$$$$$$$$$$$$$================================/
$$$        $$$


    code by Arminn_17
    https://Arminn17.ir





    {1} cpu overloader
    =====================
    {2} delete root
    =====================
    {99} back



'''

x = input("Do7ckteam=>  ")

if x == 1:
   os.system("cp modules/evilcode/cpu.py $HOME")
   print ("save in home")
if x == 2:
   os.system("cp modules/evilcode/root.py $HOME")
   print ("save in home")
if x == 99:
   os.system("python2 jrf.py")
