import os
os.system("clear")

print'''
\033[1;34m
wwww    wwww    wwww eeeeeeeeee bbbb
wwww    wwww    wwww eeeeeeeeee bbbb
wwww    wwww    wwww eeee       bbbb
wwww    wwww    wwww eeee       bbbb
wwww    wwww    wwww eeeeeeeeee bbbbbbbbbbb
wwww    wwww    wwww eeeeeeeeee bbbbbbbbbbb
wwww    wwww    wwww eeee       bbbb    bbb
wwww    wwww    wwww eeee       bbbb    bbb
wwwwwwwwwwwwwwwwwwww eeeeeeeeee bbbbbbbbbbb
wwwwwwwwwwwwwwwwwwww eeeeeeeeee bbbbbbbbbbb
\033[1;m  \033[1;32m
tttttttttt                  llll
tttttttttt                  llll
   tttt   oooooooo oooooooo llll      sssssss
   tttt   oooooooo oooooooo llll      sss
   tttt   oo    oo oo    oo llll      sssssss
   tttt   oooooooo oooooooo lllllllll     sss
   tttt   oooooooo oooooooo lllllllll sssssss



      code by Arminn_17
      https://Arminn17.ir
\033[1;m


      {1} sql dorks
      =================
      {2} xss dorks
      =================
      {99} exit



'''
x = input("Do7ckteam=>  ")

if x == 1:
   os.system("cat modules/webtools/sql.txt")
if x == 99:
   os.system("python2 jrf.py")
if x == 2:
   os.system("cat modules/webtools/xss.txt")













