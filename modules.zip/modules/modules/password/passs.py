import random

reshte = raw_input("number pass:   ");reshte = int(reshte)

print ''.join([random.choice
                (
                    'abcdefghijklmnopqrstuvwxyz'
                    +
                    'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
                    +
                    '!@#$%^&*()_+,><;./?`'
                    +
                    '1234567890'
                )
                for i in range(reshte)])
