import os

x1 = input("MIN: ")
x2 = input("MAX: ")
x3 = input("OUT: ")
x4 = input("Character: ")

code = "wordlist -m " + x1 + " -M " + x2 + " -o " + x3 + " -v " + x4
os.system(code)
