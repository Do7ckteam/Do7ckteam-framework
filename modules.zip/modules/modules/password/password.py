import os
os.system("clear")
print'''


      ===================
      ===================
      ===             ===         ********
      ===             ===         **    **
      ===             ===         ********
      ===             ===            **
  :::::::::::::::::::::::::::        **
  :::::::::::::::::::::::::::        **
  ::::::::::::::;:;;:::::::::        **
  :::::::::::::::::::::::::::        **
  :::::::::::     :::::::::::        **
  :::::::::::     :::::::::::        **
  ::::::::::::: :::::::::::::     *****
  ::::::::::::: :::::::::::::      ****
  $$$$$$$$$$$$$$$$$$$$$$$$$$$     *****



     code by Arminn_17
     https://Arminn17.ir

'''
print'''
       {1} Secure password
       ==============================
       {2} password list generator
       ==============================
       {99} back


'''
x = input("Do7ckteam=>  ")

if x == 1:
   os.system("python2 modules/password/passs.py")
if x == 2:
   os.system("python3 modules/password/passlist.py")
if x == 99:
   os.system("python2 jrf.py")
