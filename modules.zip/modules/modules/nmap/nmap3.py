import os

x = input("enter the ip:  ")

x1 = "nmap -sn " + x + "/24"

os.system(x1)
