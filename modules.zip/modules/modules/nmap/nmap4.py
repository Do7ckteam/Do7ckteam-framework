import os

x = input("enter the ip:  ")

x1 = "nmap -sV " + x 

os.system(x1)
