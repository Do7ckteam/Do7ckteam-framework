#nmap
#https://Arminn17.ir
#Arminn_17


import os

os.system("clear")




print'''
\033[1;32m
nnn          mmmmmmmmmmmmmmm $$$$$$$$$$$$   ppppppppppp
nnnnnnnnnnnn mmmmmmmmmmmmmmm          $$$   ppp    pppp
nnnnnnnnnnnn mmm:::mmm:::mmm $$$$$$$$$$$$   ppp    ppp
nnn      nnn mmm   mmm   mmm $$$$$$$$$$$$   pppppppp
nnn      nnn mmm   mmm   mmm $$$      $$$   ppp
nnn      nnn :::   :::   ::: $$$$$$$$$$%%$  pp
\033[1;m

'''


print ("      ")
print ("    ")
print ("  ")
print ("{1} port Scan")
print ("{2} simple list  scan")
print ("{3} host up scan")
print ("{4} service scan")
print ("{5} anonymous ftp scan")
print ("{99} back")
print ("   ")
print ("         ")
print ("               ")

x = input("Do7ckteam=>  ")


if x == 1:
   os.system("python3 modules/nmap/nmap1.py")
if x == 2:
   os.system("python3 modules/nmap/nmap2.py")
if x == 3:
   os.system("python3 modules/nmap/nmap3.py")
if x == 4:
   os.system("python3 modules/nmap/nmap4.py")
if x == 5:
   os.system("python3 modules/nmap/nmap5.py")
if x == 99:
   os.system("python2 jrf.py")
