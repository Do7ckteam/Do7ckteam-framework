import os

x = input("enter the ip:  ")

x1 = "nmap -sC " + x + " -p 21"
os.system(x1)
