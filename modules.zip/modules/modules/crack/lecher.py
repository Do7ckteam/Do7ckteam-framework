from bs4 import BeautifulSoup as bs
import argparse
import getpass
import json
import os
import requests
import sys
import subprocess

def LoginRequest(request):
    global session
    session = requests.Session()
    session.headers.update({'Referer': 'https://www.instagram.com/'})
    req = session.get('https://www.instagram.com/')
    session.headers.update({'X-CSRFToken': req.cookies['csrftoken']})
    login_response = session.post('https://www.instagram.com/accounts/login/ajax/', data=request, allow_redirects=True).json()
    if 'two_factor_required' in login_response and login_response['two_factor_required']:
        identifier = login_response['two_factor_info']['two_factor_identifier']
        username = credential['username']
        verification_code = input('Enter your Two-Step-Verification-Code: ')
        verification_data = {'username': username, 'verificationCode': verification_code, 'identifier': identifier}
        two_factor_response = session.post('https://www.instagram.com/accounts/login/ajax/two_factor/', data=verification_data, allow_redirects=True).json()
        if two_factor_response['authenticated']:
            return session, two_factor_response
        else:
            return None, two_factor_response
    return session, login_response
    
def login():
    user, pwd = "", ""
    while True:
        username = input("Enter your username:  ")
        password = getpass.getpass(prompt='Password: ')
        session, res = LoginRequest({"username": username, "password": password})
        if res['authenticated']:
            query_extract()
            break
        if not res['authenticated']:
            print("The username or password is incorrect")
        if res['status'] == 'fail':
            print(res['message'])
            exit() 
    return session

def main():
    parser = argparse.ArgumentParser()
    session = login()

def query_extract():
    global querylink
    m = requests.get("https://instagram.com", cookies=session.cookies, allow_redirects=True)
    r = open("html.html","wb")
    r.write(m.content)
    r.close()
    file = open("html.html","rb")
    links = bs(file.read(),'html.parser').find_all('link')
    queryreg = str(links[6])
    querylocation = queryreg.find("/graphql")
    rel = queryreg[querylocation:].find('"')
    query = queryreg[querylocation:rel+querylocation]
    querylink = "https://instagram.com"+query
    download()

def download():
    global session, querylink
    r = requests.get(querylink, cookies=session.cookies, allow_redirects=True)
    open("following.json","wb").write(r.content)
    extract()
    
def extract():
  input1 = input("Enter 1 to continue: ")
  print("")
  if input1=="1":
    pass
  else:
    exit()
  with open("followers.txt", 'w') as followers:
    with open('following.json') as data:
      data1 = json.load(data)
      placement = data1["data"]["user"]["feed_reels_tray"]["edge_reels_tray_to_reel"]["edges"]
      length = len(placement)
      for reg in range(length):
        followers.write(placement[reg]["node"]["user"]["username"] + os.linesep)
        print(placement[reg]["node"]["user"]["username"])
if __name__ == '__main__':
    main()
